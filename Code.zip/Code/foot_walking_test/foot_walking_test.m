%% Set parameters
answer = 'n';
if exist('serial_port','var')
    answer = input('Press ENTER to skip parameter specification; otherwise enter any key(s) ','s');    
end

if ~isempty(answer)
    serial_port = input('Serial Port: ','s');
    used_channels = input('Number of Channels Used: ');
    total_channels = input('Number of Channels in Total: ');
%     execution_time = input('Execution Time: ');
end

% Input validation
if used_channels > total_channels
    used_channels = total_channels;
end
% 
% if execution_time == 0
%     execution_time = 15;
% end

%% Serial port setup
if not(exist('s','var'))
    s = serial(serial_port);
    fopen(s);
end

%% Finding the start of the message
a = '';
target_message = 'BEGIN';
counter = 1;
while (counter < length(target_message))
    a = fscanf(s,'%c',1);
    if (a == target_message(counter))
        counter = counter + 1;j
    else
        counter = 1;
    end
end

'Beginning of message found'

%% Create plots and axis
plots = {1: used_channels};
for i = 1 : used_channels
    plots(i) = {animatedline};
end

plots = {animatedline('color', 'r'),animatedline('color', 'b'),animatedline('color', 'k'),animatedline('color', 'g')};
xmin = 0;
xmax = 5;
ymin = 0;
ymax = 5;

axis([xmin xmax ymin ymax])


%% Program execution
i = 1;
tic
set(gcf,'currentchar','`')         % set a dummy character
while (get(gcf, 'currentchar')=='`')
    % After the first xmax seconds begin animating the x-axis
    if toc>xmax
        axis([toc-xmax toc ymin ymax])
    end
    
    % Scan for data, expecting csv integers with total_channels elements
    if exist('y','var')
        y = [y; fread(s,1,'float'), fread(s,1,'float'), fread(s,1,'float'), fread(s,1,'float')];
    else
        y = fread(s,1,'float'), fread(s,1,'float'), fread(s,1,'float'), fread(s,1,'float');        
    end
    
    if exist('x','var')
        x = [x; toc];
    else
        x = toc;
    end
    
    % Add each of used_channels' data points to the axis
    for j = 1 : used_channels
        addpoints(plots{j},x(i),y(i,j));
    end
    drawnow
    i = i + 1;
end
 
%% Cleanup
data = horzcat(x,y(:,[1:used_channels]));
delete(s)
clearvars -except data serial_port used_channels total_channels %execution_time