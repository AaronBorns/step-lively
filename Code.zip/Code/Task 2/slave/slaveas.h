#include <Wire.h>
#include <math.h>

#define TEST_MODE 0
#define HALF_DUPLEX_MODE 1
#define FULL_DUPLEX_MODE 2
#define MODEMDEVICE "COM3"

const int BAUD_RATE = 9600;
int selected_mode = 0;
int file_descriptor;

void setup() __attribute__ ((constructor));
void cleanup() __attribute__ ((destructor));
void configure_serial();
void get_imu(int imu_address);
void get_foot();
//void get_echo(); //TBD
void get_shank_force();
void get_power();

void setup()
{
	configure_serial();
  //Wire.begin(); //Join I2C bus as master (over IMUs)
  //Serial.begin(BAUD_RATE, SERIAL_8N1);
  //while(!Serial); //Wait until Serial is fully initialized
	//Serial.println("Select a mode:\n0 = \"Test\" mode\n1 = \"Half-duplex\" mode\n2 = \"Full-duplex\" mode");
	//while (!Serial.available())
	//{
	//	selected_mode = Serial.read();
	//}
	fprintf(Serial, "Starting mode %d", selected_mode);
}

void cleanup()
{
  Serial.end();
}

void configure_serial()
{
	fd = open
}

void get_imu_reading(int imu_address)
{ 
  float imu_reading[] = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
	int imu_reading_length = sizeof(imu_reading) / sizeof(float);
	if (imu_address == 0x68)
  {
		for (int i = 0; i < imu_reading_length; i++)
		{
			imu_reading[i] = (i + 1) * 1.1;
		}
	}
  else if (imu_address == 0x69)
  {
		for (int i = 0; i < imu_reading_length; i++)
		{
			imu_reading[i] = (imu_reading_length - i) * 1.1;
		}
  }
	
  Serial.write((const uint8_t*)&imu_reading, sizeof(imu_reading));
}

void get_foot_reading()
{
  float foot_reading[] = {1.1, 2.2, 3.3, 4.4, 5.5};
  Serial.write((const uint8_t*)&foot_reading, sizeof(foot_reading));
}

void get_shank_force_reading()
{
  float shank_force_reading = 1.1;
	Serial.write((const uint8_t*)&shank_force_reading, sizeof(shank_force_reading));
}

//size_t[] get_echo_reading() {}

void get_power_reading()
{
  float power_reading = 12.34;
	Serial.write((const uint8_t*)&power_reading, sizeof(power_reading));
}

int main()
{
	String starting_message = "AAAAA";
	switch (selected_mode)
	{
	case TEST_MODE:
		fprintf(Serial, "Mode %d ready",selected_mode);
		while(1)
		{
			Serial.print(starting_message);
			int foo = 128; 															//on the receiver do fread(s,1,'int16');
			float bar = 3.14159; 												//on the receiver do fread(s,1,'float');
			float quux[] = {M_PI, 12.34, 987.6543210};	//on the receive do fread(s,3,'float');
			Serial.write((const uint8_t*)&foo,sizeof(foo));
			Serial.write((const uint8_t*)&bar,sizeof(bar));
			Serial.write((const uint8_t*)&quux,sizeof(quux));
		}
		break;
	case HALF_DUPLEX_MODE:
		fprintf(Serial, "Mode %d ready",selected_mode);
		while(1)
		{
			Serial.print(starting_message);	//char 5
			get_imu_reading(0x00);					//float 9
			get_imu_reading(0x68);					//float 9
			get_imu_reading(0x69);					//float 9
			get_foot_reading();							//float 5
			get_shank_force_reading();			//float 1
			//get_echo_reading();						//not used
			get_power_reading();						//float 1
		}
		break;

	case FULL_DUPLEX_MODE:
		fprintf(Serial, "Mode %d ready",selected_mode);
		while(1)
		{
			if (Serial.available() > 0)
			{
				int incomingByte = Serial.read();

				Serial.print("I received: ");
				Serial.println(incomingByte, DEC);
			}
		}
		break;
	}

	return 0;
}