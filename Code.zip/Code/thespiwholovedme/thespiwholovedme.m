%% Set parameters
answer = 'n';
if exist('serial_port','var')
    answer = input('Press ENTER to skip parameter specification; otherwise enter any key(s) ','s');    
end

if ~isempty(answer)
    serial_port = input('Serial Port: ','s');
    used_channels = input('Number of Channels Used: ');
    total_channels = input('Number of Channels in Total: ');
    execution_time = input('Execution Time: ');
end

% Input validation
if used_channels > total_channels
    used_channels = total_channels;
end

if execution_time == 0
    execution_time = 15;
end

%% Serial port setup
if not(exist('b','var'))
    b = serial(serial_port);
    fopen(b);
end

%% Create plots and axis
plots = {1: used_channels};
for i = 1 : used_channels
    plots(i) = {animatedline};
end

xmin = 0;
xmax = 5;
ymin = 200;
ymax = 700;

axis([xmin xmax ymin ymax])

%% Miscellaneous setup
fscanf(b); % Dummy command throws out the first fscanf which often has garbage characters in it
tic % Starts the timer

%% Program execution
i = 1;
while(toc < execution_time)
    % After the first xmax seconds begin animating the x-axis
    if toc>xmax
        axis([toc-xmax toc ymin ymax])
    end
    
    % Scan for data, expecting csv integers with total_channels elements
    if exist('y','var')
        y = [y; fscanf(b, strcat('%u',repmat(',%u', 1, total_channels - 1),';'),[1 total_channels])];
    else
        y = fscanf(b, strcat('%u',repmat(',%u', 1, total_channels - 1),';'),[1 total_channels]);
    end
    
    if exist('x','var')
        x = [x; toc];
    else
        x = toc;
    end
    
    % Add each of used_channels' data points to the axis
    for j = 1 : used_channels
        addpoints(plots{j},x(i),y(i,j));
    end
    drawnow
    i = i + 1;
end

%% Cleanup
data = horzcat(x,y(:,[1 used_channels]));
delete(b)
clearvars -except data serial_port used_channels total_channels execution_time