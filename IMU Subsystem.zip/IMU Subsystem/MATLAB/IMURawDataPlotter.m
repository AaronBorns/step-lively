close all
clc
clear
fclose(instrfind);
s = serial('COM5','BaudRate',10000);
fopen(s);
AcX =[];
AcY =[];
AcZ =[];
GyX =[];
GyY =[];
GyZ =[];

%fig = figure(1)
sensor_number=6;    %working case plotting 5 channels not 6
z = zeros(sensor_number,50);
% for sensor_number, take into consideration leading 0 value in Arduino IDE
% code.
for j = 1:200
    for i = 1:10
        str = fscanf(s)
        z(:,i) = decode(str)'
        
    end
    AcX =[AcX z(1,:)];
    AcY =[AcY z(2,:)];
    AcZ =[AcZ z(3,:)];
   GyX =[GyX z(4,:)];
   GyY =[GyY z(5,:)];
   GyZ =[GyZ z(6,:)];

    subplot(3,1,1)
    h1=plot(AcX*2*pi/(2^16));
    % the 2^16 denomenator is directly related with the arduino datatype
    % (unit16_t) of our 6 channels.
    subplot(4,1,2)
    h2=plot(AcY*2*pi/(2^16));
     subplot(4,1,3)
    h3=plot(AcZ*2*pi/(2^16));
     subplot(4,1,4)
    h4=plot(GyX*2*pi/(2^16));
%     subplot(6,1,5)
%     h5=plot(GyY(20*j:20*j+30));
%     subplot(6,1,6)
%     h6=plot(GyZ(20*j:20*j+30));
    drawnow
end
fclose(instrfind);
function output = decode(str)
Key = ',';
Index = strfind(str,Key);
for i = 0:length(Index)-1 
    output(i+1) = sscanf(str(Index(i+1) + length(Key):end),'%g',1);
end
end